#!/bin/bash
set -e

# Create macOS .app bundle for Niimi
# This creates a double-clickable application that launches Niimi and opens the browser

APP_NAME="Niimi"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Creating ${APP_NAME}.app bundle..."

# Create app bundle structure
mkdir -p "${APP_NAME}.app/Contents/MacOS"
mkdir -p "${APP_NAME}.app/Contents/Resources"

# Create Info.plist
cat > "${APP_NAME}.app/Contents/Info.plist" << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>Niimi</string>
    <key>CFBundleIdentifier</key>
    <string>com.niimi.app</string>
    <key>CFBundleName</key>
    <string>Niimi</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleShortVersionString</key>
    <string>3.0.0</string>
    <key>CFBundleVersion</key>
    <string>3.0.0</string>
    <key>LSMinimumSystemVersion</key>
    <string>11.0</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
EOF

# Create executable launcher script
cat > "${APP_NAME}.app/Contents/MacOS/${APP_NAME}" << 'EOF'
#!/bin/bash

# Add common binary paths for GUI apps
export PATH="/usr/local/bin:/opt/homebrew/bin:$PATH"

# Get the directory where this app bundle is located
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../" && pwd)"
cd "$APP_DIR"

# Check if .env exists
if [ ! -f ".env" ]; then
    osascript -e 'display dialog "Error: .env file not found!\n\nPlease configure your .env file first." buttons {"OK"} default button "OK" with icon stop with title "Niimi"'
    exit 1
fi

# Check if niimi is already running
if lsof -i :5443 &> /dev/null; then
    # Server already running, just open browser
    sleep 1
    open "http://localhost:5443/video-chat.html"
    exit 0
fi

# Start niimi in background
./niimi > /tmp/niimi.log 2>&1 &
NIIMI_PID=$!

# Save PID for later cleanup
echo $NIIMI_PID > /tmp/niimi.pid

# Wait for server to start (max 10 seconds)
echo "Starting Niimi server..."
for i in {1..20}; do
    if lsof -i :5443 &> /dev/null; then
        echo "Server started successfully"
        break
    fi
    sleep 0.5
done

# Check if server actually started
if ! lsof -i :5443 &> /dev/null; then
    osascript -e 'display dialog "Error: Failed to start Niimi server.\n\nCheck /tmp/niimi.log for details." buttons {"OK"} default button "OK" with icon stop with title "Niimi"'
    exit 1
fi

# Open browser
sleep 1
open "http://localhost:5443/video-chat.html"

# Show success notification
osascript -e 'display notification "Niimi is running on http://localhost:5443" with title "Niimi Started"'

exit 0
EOF

# Make the launcher executable
chmod +x "${APP_NAME}.app/Contents/MacOS/${APP_NAME}"

echo "Successfully created ${APP_NAME}.app"
echo ""
echo "To use:"
echo "  1. Double-click ${APP_NAME}.app to launch"
echo "  2. Browser will open automatically to video chat"
echo "  3. To stop: Use Activity Monitor to quit 'niimi' process"
echo ""
echo "You can move ${APP_NAME}.app to your Applications folder or desktop."
