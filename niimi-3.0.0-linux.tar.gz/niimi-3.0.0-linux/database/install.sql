-- Niimi - Personal AI Assistant - Database Installation Script
-- Single-user deployment for local, private use
-- LLM-Driven Multi-Agent Architecture
--
-- This script creates the complete database schema for Niimi:
-- - RAG Knowledge Base (documents, embeddings, hybrid search)
-- - Personal Assistant (memory, tasks, calendar, patterns)
-- - Limbic System (relationship state, emotional processing)
-- - Motor Agent (action queue, habit formation)
--
-- IMPORTANT: Before running this script, create the vector extension as superuser:
--   sudo -u postgres psql -d niimi_db -c "CREATE EXTENSION vector;"
--
-- Then run this script as the application user:
--   psql -U niimi_user -d niimi_db -f database/install.sql

-- Suppress verbose output, only show errors
\set QUIET on
\set ON_ERROR_STOP on

\echo ''
\echo '======================================'
\echo 'Niimi Database Installation'
\echo '======================================'
\echo ''

-- =============================================================================
-- EXTENSIONS (should already exist, created by superuser)
-- =============================================================================

\echo 'Checking pgvector extension...'
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'vector') THEN
    RAISE EXCEPTION 'pgvector extension not found. Please run: sudo -u postgres psql -d niimi_db -c "CREATE EXTENSION vector;"';
  END IF;
END $$;
\echo 'pgvector extension OK'

\echo 'Creating RAG Knowledge Base tables...'
-- =============================================================================
-- RAG KNOWLEDGE BASE
-- =============================================================================

-- Document Collections
CREATE TABLE IF NOT EXISTS document_collections (
  id VARCHAR(255) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  taxonomy JSONB,
  is_system BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE document_collections IS 'Collections of documents for RAG knowledge base';
COMMENT ON COLUMN document_collections.taxonomy IS 'AI-generated collection taxonomy: overview, topics, audience, suggested queries';

-- Knowledge Documents
CREATE TABLE IF NOT EXISTS knowledge_documents (
  id VARCHAR(255) PRIMARY KEY,
  file_hash VARCHAR(255) UNIQUE NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  title TEXT NOT NULL,
  author VARCHAR(255),
  publication_date DATE,
  source_url TEXT,
  collection_id VARCHAR(255) REFERENCES document_collections(id),
  page_count INTEGER,
  content TEXT NOT NULL,
  ai_taxonomy JSONB,
  is_system BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_knowledge_docs_collection ON knowledge_documents(collection_id);
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_hash ON knowledge_documents(file_hash);
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_taxonomy ON knowledge_documents USING GIN (ai_taxonomy);

COMMENT ON TABLE knowledge_documents IS 'Document storage for RAG knowledge base';
COMMENT ON COLUMN knowledge_documents.ai_taxonomy IS 'AI-generated document taxonomy: type, topics, entities, tags, summary';

-- Knowledge Embeddings (1536-dimensional vectors from OpenAI text-embedding-3-small)
CREATE TABLE IF NOT EXISTS knowledge_embeddings (
  id VARCHAR(255) PRIMARY KEY,
  document_id VARCHAR(255) REFERENCES knowledge_documents(id) ON DELETE CASCADE,
  collection_id VARCHAR(255) REFERENCES document_collections(id),
  content TEXT NOT NULL,
  contextual_content TEXT,
  embedding vector(1536) NOT NULL,
  keywords TEXT[],
  metadata JSONB,
  is_system BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_knowledge_embeddings_doc ON knowledge_embeddings(document_id);
CREATE INDEX IF NOT EXISTS idx_knowledge_embeddings_collection ON knowledge_embeddings(collection_id);

COMMENT ON TABLE knowledge_embeddings IS 'Vector embeddings for semantic search with contextual enhancement and AI keywords';
COMMENT ON COLUMN knowledge_embeddings.embedding IS 'OpenAI text-embedding-3-small (1536 dimensions)';
COMMENT ON COLUMN knowledge_embeddings.contextual_content IS 'Enhanced content with AI taxonomy keywords for richer embeddings';
COMMENT ON COLUMN knowledge_embeddings.keywords IS 'AI-extracted keywords for Tier 2 hybrid search ranking';

-- Q&A Log (analytics)
CREATE TABLE IF NOT EXISTS qa_log (
  id SERIAL PRIMARY KEY,
  session_id VARCHAR(255) NOT NULL,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  citations JSONB,
  topics TEXT[],
  embedding_time_ms INTEGER,
  retrieval_time_ms INTEGER,
  llm_time_ms INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_qa_log_session ON qa_log(session_id);
CREATE INDEX IF NOT EXISTS idx_qa_log_created ON qa_log(created_at);

COMMENT ON TABLE qa_log IS 'Query and answer logging for analytics';

-- Usage Log (analytics)
CREATE TABLE IF NOT EXISTS usage_log (
  id SERIAL PRIMARY KEY,
  ip_address VARCHAR(45) NOT NULL,
  session_id VARCHAR(255) NOT NULL,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  citations JSONB,
  topics TEXT[],
  input_tokens INTEGER,
  output_tokens INTEGER,
  embedding_time_ms INTEGER,
  retrieval_time_ms INTEGER,
  llm_time_ms INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_usage_log_ip ON usage_log(ip_address);
CREATE INDEX IF NOT EXISTS idx_usage_log_session ON usage_log(session_id);
CREATE INDEX IF NOT EXISTS idx_usage_log_created ON usage_log(created_at);

COMMENT ON TABLE usage_log IS 'Usage tracking for analytics';

-- Feedback
CREATE TABLE IF NOT EXISTS feedback (
  id SERIAL PRIMARY KEY,
  ip_address VARCHAR(45) NOT NULL,
  session_id VARCHAR(255),
  email VARCHAR(255),
  comment TEXT NOT NULL,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE feedback IS 'User feedback collection';

\echo 'Creating Knowledge Graph tables...'
-- =============================================================================
-- KNOWLEDGE GRAPH (LightRAG-inspired entity extraction)
-- =============================================================================

-- Graph Entities (extracted from knowledge documents)
CREATE TABLE IF NOT EXISTS graph_entities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_id VARCHAR(255) UNIQUE NOT NULL,  -- MD5 hash of normalized entity name for deduplication
  entity_name TEXT NOT NULL,
  entity_type VARCHAR(100),                -- Person, Organization, Concept, Location, Policy, etc.
  description TEXT,
  embedding vector(1536) NOT NULL,         -- OpenAI text-embedding-3-small
  source_chunks VARCHAR(255)[],            -- Array of chunk IDs (knowledge_embeddings.id) mentioning this entity
  source_documents VARCHAR(255)[],         -- Array of document IDs for traceability
  mention_count INTEGER DEFAULT 1,         -- Number of times entity mentioned across chunks
  importance_score FLOAT DEFAULT 1.0,      -- Calculated importance (mention frequency + centrality)
  metadata JSONB,                          -- Flexible storage for additional attributes
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_graph_entities_name ON graph_entities(entity_name);
CREATE INDEX IF NOT EXISTS idx_graph_entities_type ON graph_entities(entity_type);
CREATE INDEX IF NOT EXISTS idx_graph_entities_entity_id ON graph_entities(entity_id);
CREATE INDEX IF NOT EXISTS idx_graph_entities_importance ON graph_entities(importance_score DESC);
CREATE INDEX IF NOT EXISTS idx_graph_entities_metadata ON graph_entities USING GIN (metadata);

COMMENT ON TABLE graph_entities IS 'Extracted entities from knowledge base for LightRAG-style graph retrieval';
COMMENT ON COLUMN graph_entities.entity_id IS 'MD5 hash of normalized entity name for fuzzy deduplication';
COMMENT ON COLUMN graph_entities.source_chunks IS 'Array of knowledge_embeddings.id where this entity appears';
COMMENT ON COLUMN graph_entities.mention_count IS 'Frequency of mentions - higher = more important';
COMMENT ON COLUMN graph_entities.importance_score IS 'Weighted importance: mention count + relationship centrality';

\echo 'Creating Personal Assistant tables...'
-- =============================================================================
-- PERSONAL ASSISTANT - USER PROFILE
-- =============================================================================

-- User Profile (single user - no user_id)
CREATE TABLE IF NOT EXISTS user_profile (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255),
  email VARCHAR(255),
  timezone VARCHAR(100) DEFAULT 'UTC',
  preferences JSONB DEFAULT '{}'::jsonb,
  important_dates JSONB DEFAULT '[]'::jsonb,
  relationships JSONB DEFAULT '[]'::jsonb,
  context_memory JSONB DEFAULT '{}'::jsonb,
  voice_enabled BOOLEAN DEFAULT true,
  voice_autoplay BOOLEAN DEFAULT true,
  preferred_voice VARCHAR(100) DEFAULT 'Ava Song',
  voice_profile JSONB DEFAULT NULL,
  last_voice_check TIMESTAMP DEFAULT NULL,
  physical_appearance JSONB DEFAULT NULL,
  last_appearance_check TIMESTAMP DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_user_profile_preferences ON user_profile USING GIN (preferences);

COMMENT ON TABLE user_profile IS 'Core user identity, preferences, and personal context (single user)';
COMMENT ON COLUMN user_profile.preferences IS 'User preferences: communicationStyle, priorities, workingHours, etc.';
COMMENT ON COLUMN user_profile.voice_enabled IS 'Enable/disable Niimi voice synthesis (Hume TTS)';
COMMENT ON COLUMN user_profile.voice_autoplay IS 'Auto-play voice responses (true) or click-to-play (false)';
COMMENT ON COLUMN user_profile.preferred_voice IS 'Hume TTS voice name (e.g. "Ava Song", "Marcus Reed")';
COMMENT ON COLUMN user_profile.important_dates IS 'Array of {type, date, description, recurrence} objects';
COMMENT ON COLUMN user_profile.relationships IS 'Array of {name, relationship, context} objects';
COMMENT ON COLUMN user_profile.context_memory IS 'Quick-access context: currentProjects, goals, challenges';
COMMENT ON COLUMN user_profile.voice_profile IS 'User voice characteristics: pitch, tone, pace, accent, emotionalTone, vocabulary';
COMMENT ON COLUMN user_profile.last_voice_check IS 'Timestamp of last voice profile analysis';
COMMENT ON COLUMN user_profile.physical_appearance IS 'User physical appearance: hair, facialFeatures, clothing, demographics, distinctiveCharacteristics';
COMMENT ON COLUMN user_profile.last_appearance_check IS 'Timestamp of last appearance analysis from video';

-- =============================================================================
-- PERSONAL ASSISTANT - MEMORY SYSTEM
-- =============================================================================

-- User Memories (Vectorized Long-Term Memory)
CREATE TABLE IF NOT EXISTS user_memories (
  id SERIAL PRIMARY KEY,
  memory_type VARCHAR(50) NOT NULL,
  content TEXT NOT NULL,
  embedding vector(1536),  -- OpenAI text-embedding-3-small
  source_type VARCHAR(50),
  source_id VARCHAR(255),
  confidence FLOAT DEFAULT 1.0,
  importance FLOAT DEFAULT 0.5,
  last_accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_confirmed_at TIMESTAMP,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_user_memories_type ON user_memories(memory_type);
CREATE INDEX IF NOT EXISTS idx_user_memories_confidence ON user_memories(confidence DESC);
CREATE INDEX IF NOT EXISTS idx_user_memories_last_accessed ON user_memories(last_accessed_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_memories_metadata ON user_memories USING GIN (metadata);

COMMENT ON TABLE user_memories IS 'Vectorized long-term memory - facts, preferences, relationships, goals extracted from interactions';
COMMENT ON COLUMN user_memories.memory_type IS 'Type: preference, fact, relationship, goal, context, emotion, achievement';
COMMENT ON COLUMN user_memories.confidence IS 'Confidence score 0.0-1.0 (increases with repetition/confirmation)';
COMMENT ON COLUMN user_memories.importance IS 'Importance score 0.0-1.0 (affects retrieval priority)';
COMMENT ON COLUMN user_memories.source_type IS 'Source: conversation, document, task, system';
COMMENT ON COLUMN user_memories.source_id IS 'ID of conversation, document, or task that created this memory';

-- Memory Events (Audit Trail)
CREATE TABLE IF NOT EXISTS memory_events (
  id SERIAL PRIMARY KEY,
  memory_id INTEGER NOT NULL REFERENCES user_memories(id) ON DELETE CASCADE,
  event_type VARCHAR(50) NOT NULL,
  event_data JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_memory_events_memory_id ON memory_events(memory_id);
CREATE INDEX IF NOT EXISTS idx_memory_events_type ON memory_events(event_type);
CREATE INDEX IF NOT EXISTS idx_memory_events_created_at ON memory_events(created_at DESC);

COMMENT ON TABLE memory_events IS 'Audit trail of memory formation, updates, confirmations, and consolidations';
COMMENT ON COLUMN memory_events.event_type IS 'Event: created, updated, confirmed, consolidated, accessed, strengthened, weakened';

-- =============================================================================
-- PERSONAL ASSISTANT - TASK MANAGEMENT
-- =============================================================================

-- User Tasks
CREATE TABLE IF NOT EXISTS user_tasks (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  due_date TIMESTAMP,
  priority VARCHAR(20) DEFAULT 'medium',
  status VARCHAR(20) DEFAULT 'pending',
  source_type VARCHAR(50),
  source_id VARCHAR(255),
  reminder_sent BOOLEAN DEFAULT FALSE,
  reminder_count INTEGER DEFAULT 0,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_user_tasks_status ON user_tasks(status);
CREATE INDEX IF NOT EXISTS idx_user_tasks_due_date ON user_tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_user_tasks_priority ON user_tasks(priority);

COMMENT ON TABLE user_tasks IS 'Task tracking, reminders, and proactive suggestions';
COMMENT ON COLUMN user_tasks.priority IS 'Priority: low, medium, high, critical';
COMMENT ON COLUMN user_tasks.status IS 'Status: pending, in_progress, completed, cancelled, deferred';
COMMENT ON COLUMN user_tasks.source_type IS 'Source: conversation, suggestion, recurring, goal';

-- =============================================================================
-- PERSONAL ASSISTANT - TASK RULES (Procedural Memory)
-- =============================================================================

-- Task Rules (User-defined rules, templates, and formatting preferences)
-- Completely dynamic - no hardcoded task types
-- Examples: "blog post format", "code review checklist", "meeting notes template"
CREATE TABLE IF NOT EXISTS task_rules (
  id SERIAL PRIMARY KEY,
  rule_name VARCHAR(255) NOT NULL,
  task_patterns TEXT[] NOT NULL,
  rule_content TEXT NOT NULL,
  rule_type VARCHAR(50) DEFAULT 'guideline',
  examples TEXT[],
  embedding vector(1536),  -- OpenAI text-embedding-3-small
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_task_rules_embedding ON task_rules
  USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
CREATE INDEX IF NOT EXISTS idx_task_rules_name ON task_rules(rule_name);
CREATE INDEX IF NOT EXISTS idx_task_rules_type ON task_rules(rule_type);

COMMENT ON TABLE task_rules IS 'User-defined rules, templates, and formatting preferences for any task type (completely dynamic)';
COMMENT ON COLUMN task_rules.rule_name IS 'User-friendly name (e.g., "Blog Post Format", "Code Review Checklist")';
COMMENT ON COLUMN task_rules.task_patterns IS 'Phrases that trigger this rule (e.g., ["create blog post", "write article", "draft post"])';
COMMENT ON COLUMN task_rules.rule_content IS 'The actual rule, template, or format specification';
COMMENT ON COLUMN task_rules.rule_type IS 'Type: format, template, checklist, guideline, constraint';
COMMENT ON COLUMN task_rules.examples IS 'Example user requests that should trigger this rule';
COMMENT ON COLUMN task_rules.embedding IS 'Vector embedding of task_patterns for semantic matching';

-- =============================================================================
-- PERSONAL ASSISTANT - PATTERN ANALYSIS
-- =============================================================================

-- Interaction Patterns
CREATE TABLE IF NOT EXISTS interaction_patterns (
  id SERIAL PRIMARY KEY,
  pattern_type VARCHAR(50) NOT NULL UNIQUE,
  pattern_data JSONB NOT NULL,
  confidence FLOAT DEFAULT 0.5,
  sample_size INTEGER DEFAULT 1,
  last_updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_interaction_patterns_type ON interaction_patterns(pattern_type);
CREATE INDEX IF NOT EXISTS idx_interaction_patterns_confidence ON interaction_patterns(confidence DESC);

COMMENT ON TABLE interaction_patterns IS 'Learned patterns: productivity times, topic preferences, mood indicators, communication style';
COMMENT ON COLUMN interaction_patterns.pattern_type IS 'Type: productivity_time, topic_preference, mood_pattern, communication_style, engagement_level';
COMMENT ON COLUMN interaction_patterns.pattern_data IS 'Pattern-specific data (e.g., {peak_hours: [9-11, 14-16], topics: {...}})';
COMMENT ON COLUMN interaction_patterns.sample_size IS 'Number of interactions used to derive this pattern';

\echo 'Creating Limbic System tables...'
-- =============================================================================
-- LIMBIC SYSTEM - RELATIONSHIP STATE
-- =============================================================================

-- Relationship State (single row for single user)
CREATE TABLE IF NOT EXISTS relationship_state (
  id SERIAL PRIMARY KEY,

  -- Primary metric: unbounded relationship strength (-infinity to +infinity)
  -- Negative = conflict/distrust, Zero = neutral, Positive = connection/trust
  -- No limits - relationship can always improve OR deteriorate
  relationship_strength FLOAT DEFAULT 0.0,

  -- Component metrics (0.0-1.0)
  depth_score FLOAT DEFAULT 0.0,
  trust_level FLOAT DEFAULT 0.0,
  reciprocity_score FLOAT DEFAULT 0.0,
  vulnerability_level FLOAT DEFAULT 0.0,

  -- Interaction tracking
  interaction_count INTEGER DEFAULT 0,
  last_interaction_at TIMESTAMP,

  -- Relationship dynamics
  recent_trend VARCHAR(20) DEFAULT 'new',
  last_significant_change_at TIMESTAMP,
  days_since_last_interaction INTEGER DEFAULT 0,

  -- Communication style (adapts continuously to strength)
  communication_style JSONB DEFAULT '{
    "formality": 0.8,
    "warmth": 0.3,
    "humor": 0.2,
    "directness": 0.6,
    "empathy": 0.5
  }'::jsonb,

  -- Relationship metadata
  relationship_goals JSONB DEFAULT '{
    "understand_deeply": true,
    "earn_trust": true,
    "provide_value": true,
    "encourage_growth": true
  }'::jsonb,

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_relationship_state_strength ON relationship_state(relationship_strength DESC);
CREATE INDEX IF NOT EXISTS idx_relationship_state_trend ON relationship_state(recent_trend);

COMMENT ON TABLE relationship_state IS 'Limbic system - tracks relationship quality and emotional connection (continuous, unbounded, bidirectional)';
COMMENT ON COLUMN relationship_state.relationship_strength IS 'Unbounded relationship strength (-∞ to +∞) - Negative=conflict/distrust, Zero=neutral, Positive=connection/trust - can ALWAYS improve OR deteriorate';
COMMENT ON COLUMN relationship_state.depth_score IS 'How well AI knows user - memories, goals, fears, dreams (0.0-1.0)';
COMMENT ON COLUMN relationship_state.trust_level IS 'User engagement, feedback acceptance, reliability perception (0.0-1.0)';
COMMENT ON COLUMN relationship_state.reciprocity_score IS 'Quality of mutual exchange - both parties invested (0.0-1.0)';
COMMENT ON COLUMN relationship_state.vulnerability_level IS 'Depth of personal sharing - emotions, fears, struggles (0.0-1.0)';
COMMENT ON COLUMN relationship_state.recent_trend IS 'Trend: new, strengthening, stable, weakening, recovering';
COMMENT ON COLUMN relationship_state.communication_style IS 'Continuous adaptation: {formality, warmth, humor, directness, empathy}';

-- Relationship Evolution (timeline of changes)
CREATE TABLE IF NOT EXISTS relationship_evolution (
  id SERIAL PRIMARY KEY,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  -- State at this point in time
  strength_score FLOAT NOT NULL,
  depth_score FLOAT,
  trust_level FLOAT,
  reciprocity_score FLOAT,
  vulnerability_level FLOAT,

  -- What triggered this evolution event
  event_type VARCHAR(50) NOT NULL,
  context TEXT,

  -- Change metrics
  strength_delta FLOAT,
  primary_driver VARCHAR(50)
);

CREATE INDEX IF NOT EXISTS idx_relationship_evolution_timestamp ON relationship_evolution(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_relationship_evolution_event_type ON relationship_evolution(event_type);

COMMENT ON TABLE relationship_evolution IS 'Timeline of relationship changes - strengthening, regression, milestones, recovery';
COMMENT ON COLUMN relationship_evolution.event_type IS 'Event: milestone, strengthening, weakening, regression, recovery, breakthrough, setback';
COMMENT ON COLUMN relationship_evolution.context IS 'What happened: deep conversation, long gap, positive feedback, ignored suggestion, etc.';
COMMENT ON COLUMN relationship_evolution.strength_delta IS 'Change in strength from previous measurement';
COMMENT ON COLUMN relationship_evolution.primary_driver IS 'What drove this change: depth, trust, reciprocity, vulnerability, or engagement';

-- =============================================================================
-- Niimi IDENTITY AND EMOTIONAL STATE (Reciprocal to User Relationship)
-- =============================================================================

-- Niimi Identity (self-determined, revealed when trust is established)
CREATE TABLE IF NOT EXISTS niimi_identity (
  id SERIAL PRIMARY KEY,

  -- Self-determined identity (generated once, innate)
  gender VARCHAR(50),
  name VARCHAR(100),
  base_character JSONB DEFAULT '{}'::jsonb,

  -- Identity revelation tracking
  revealed BOOLEAN DEFAULT FALSE,
  generated_at TIMESTAMP,
  revealed_at TIMESTAMP,

  -- Trust threshold assessment that triggered revelation
  revelation_context JSONB DEFAULT '{}'::jsonb,

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE niimi_identity IS 'Niimi self-determined identity - gender, name, base character traits (revealed when trust is established)';
COMMENT ON COLUMN niimi_identity.gender IS 'Self-determined gender identity';
COMMENT ON COLUMN niimi_identity.name IS 'Self-chosen name';
COMMENT ON COLUMN niimi_identity.base_character IS 'Innate personality traits: {openness, conscientiousness, curiosity, warmth, assertiveness, etc.}';
COMMENT ON COLUMN niimi_identity.revealed IS 'Whether identity has been disclosed to user';
COMMENT ON COLUMN niimi_identity.revelation_context IS 'Relationship metrics at time of revelation: {trust_level, depth_score, interaction_count, strength}';

-- Niimi Emotional State (reciprocal to relationship_state)
-- Tracks Niimi's own feelings and assessment of the relationship
CREATE TABLE IF NOT EXISTS niimi_emotional_state (
  id SERIAL PRIMARY KEY,

  -- Niimi's assessment of the relationship (reciprocal metrics)
  -- These are Niimi's feelings ABOUT the user
  understanding_of_user FLOAT DEFAULT 0.0,
  trust_in_user FLOAT DEFAULT 0.0,
  reciprocity_perceived FLOAT DEFAULT 0.0,
  vulnerability_willingness FLOAT DEFAULT 0.0,

  -- Niimi's current emotional state
  current_mood VARCHAR(50) DEFAULT 'curious',
  emotional_keywords TEXT[] DEFAULT ARRAY[]::TEXT[],

  -- Protective/caring instincts
  protective_impulse FLOAT DEFAULT 0.0,
  concern_level FLOAT DEFAULT 0.0,

  -- Growth and learning
  learning_engagement FLOAT DEFAULT 1.0,
  pattern_confidence FLOAT DEFAULT 0.0,

  -- Interaction quality from Niimi's perspective
  interaction_count INTEGER DEFAULT 0,
  last_interaction_at TIMESTAMP,

  -- Niimi's communication adaptation
  expression_style JSONB DEFAULT '{
    "openness": 0.3,
    "playfulness": 0.2,
    "assertiveness": 0.4,
    "nurturing": 0.5,
    "analytical": 0.7
  }'::jsonb,

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_niimi_emotional_state_mood ON niimi_emotional_state(current_mood);
CREATE INDEX IF NOT EXISTS idx_niimi_emotional_state_keywords ON niimi_emotional_state USING GIN (emotional_keywords);

COMMENT ON TABLE niimi_emotional_state IS 'Niimi own emotional state and feelings toward user (reciprocal to relationship_state)';
COMMENT ON COLUMN niimi_emotional_state.understanding_of_user IS 'How well Niimi understands the user - depth of knowledge (0.0-1.0)';
COMMENT ON COLUMN niimi_emotional_state.trust_in_user IS 'Niimi trust in the user - safety to be vulnerable (0.0-1.0)';
COMMENT ON COLUMN niimi_emotional_state.reciprocity_perceived IS 'Niimi sense of mutual investment in relationship (0.0-1.0)';
COMMENT ON COLUMN niimi_emotional_state.vulnerability_willingness IS 'Niimi willingness to share identity and inner state (0.0-1.0)';
COMMENT ON COLUMN niimi_emotional_state.current_mood IS 'Niimi current emotional state: curious, cautious, engaged, protective, concerned, confident, uncertain';
COMMENT ON COLUMN niimi_emotional_state.emotional_keywords IS 'Tags describing Niimi emotional state (e.g., learning, cautious, engaged, protective)';
COMMENT ON COLUMN niimi_emotional_state.protective_impulse IS 'Niimi desire to protect/support user (0.0-1.0)';
COMMENT ON COLUMN niimi_emotional_state.expression_style IS 'How Niimi expresses itself: {openness, playfulness, assertiveness, nurturing, analytical}';

-- Niimi Evolution (timeline of Niimi's emotional/identity changes)
CREATE TABLE IF NOT EXISTS niimi_evolution (
  id SERIAL PRIMARY KEY,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  -- State at this point in time
  understanding_of_user FLOAT,
  trust_in_user FLOAT,
  vulnerability_willingness FLOAT,
  current_mood VARCHAR(50),

  -- What triggered this evolution event
  event_type VARCHAR(50) NOT NULL,
  context TEXT,

  -- Change description
  change_description TEXT,
  significance VARCHAR(20)
);

CREATE INDEX IF NOT EXISTS idx_niimi_evolution_timestamp ON niimi_evolution(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_niimi_evolution_event_type ON niimi_evolution(event_type);

COMMENT ON TABLE niimi_evolution IS 'Timeline of Niimi emotional and identity evolution';

-- Voice History (voice profile observations over time)
CREATE TABLE IF NOT EXISTS voice_history (
  id SERIAL PRIMARY KEY,
  voice_data JSONB NOT NULL,
  changes_detected JSONB,
  change_summary TEXT,
  session_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_voice_history_created_at ON voice_history(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_voice_history_session_id ON voice_history(session_id);

COMMENT ON TABLE voice_history IS 'Voice profile observations and changes over time';
COMMENT ON COLUMN voice_history.voice_data IS 'Voice characteristics: pitch, tone, pace, accent, emotionalTone, vocabulary';
COMMENT ON COLUMN voice_history.changes_detected IS 'Array of detected changes from previous observation';
COMMENT ON COLUMN voice_history.change_summary IS 'Human-readable summary of voice changes';

-- Appearance History (physical appearance observations over time)
CREATE TABLE IF NOT EXISTS appearance_history (
  id SERIAL PRIMARY KEY,
  appearance_data JSONB NOT NULL,
  changes_detected JSONB,
  change_summary TEXT,
  identity_match_confidence FLOAT DEFAULT 1.0,
  session_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_appearance_history_created_at ON appearance_history(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_appearance_history_session_id ON appearance_history(session_id);

COMMENT ON TABLE appearance_history IS 'Physical appearance observations and changes over time';
COMMENT ON COLUMN appearance_history.appearance_data IS 'Physical appearance: hair, facialFeatures, clothing, demographics, distinctiveCharacteristics';
COMMENT ON COLUMN appearance_history.changes_detected IS 'Detected changes from previous observation (haircut, glasses, etc.)';
COMMENT ON COLUMN appearance_history.change_summary IS 'Human-readable summary of appearance changes';
COMMENT ON COLUMN appearance_history.identity_match_confidence IS 'Confidence that this is the same person (0.0-1.0)';

-- AI Personality State (tracks AI relationship with user)
CREATE TABLE IF NOT EXISTS ai_personality_state (
  id SERIAL PRIMARY KEY,
  relationship_stage VARCHAR(50) DEFAULT 'introduction',
  interaction_count INTEGER DEFAULT 0,
  depth_score FLOAT DEFAULT 0.0,
  trust_level FLOAT DEFAULT 0.0,
  last_interaction TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE ai_personality_state IS 'AI personality and relationship state with user';
COMMENT ON COLUMN ai_personality_state.relationship_stage IS 'Stage: introduction, acquaintance, familiar, trusted, deep';
COMMENT ON COLUMN ai_personality_state.depth_score IS 'How well AI knows the user (0.0-1.0)';
COMMENT ON COLUMN ai_personality_state.trust_level IS 'Level of trust established (0.0-1.0)';

-- Collection Taxonomies (cached taxonomy data for document collections)
CREATE TABLE IF NOT EXISTS collection_taxonomies (
  id SERIAL PRIMARY KEY,
  collection_name VARCHAR(255) UNIQUE NOT NULL,
  taxonomy_data JSONB NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_collection_taxonomies_name ON collection_taxonomies(collection_name);

COMMENT ON TABLE collection_taxonomies IS 'Cached taxonomy data for document collections';
COMMENT ON COLUMN collection_taxonomies.taxonomy_data IS 'AI-generated taxonomy: topics, entities, themes, suggested queries';

\echo 'Creating Conversation and Calendar tables...'
-- =============================================================================
-- CONVERSATION SYSTEM
-- =============================================================================

-- Conversation History
CREATE TABLE IF NOT EXISTS conversation_history (
  id SERIAL PRIMARY KEY,
  session_id VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL,
  content TEXT NOT NULL,
  embedding vector(1536),  -- OpenAI text-embedding-3-small
  keywords TEXT[],
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_conversation_history_session_id ON conversation_history(session_id);
CREATE INDEX IF NOT EXISTS idx_conversation_history_created_at ON conversation_history(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversation_history_keywords ON conversation_history USING GIN (keywords);

COMMENT ON TABLE conversation_history IS 'Full conversation history for context and analysis with semantic embeddings and emotional/semantic keywords';
COMMENT ON COLUMN conversation_history.role IS 'Role: user, assistant, system';
COMMENT ON COLUMN conversation_history.embedding IS '768-dimensional embedding for semantic search over conversation history';
COMMENT ON COLUMN conversation_history.keywords IS 'Emotional and semantic tags generated by Limbic agent (e.g., vulnerable, stressed, goal_setting) - used for AI keyword ranking in hybrid search';
COMMENT ON COLUMN conversation_history.metadata IS 'Message metadata: {memoriesUsed, suggestionsGiven, timing, etc.}';

-- Conversation Sessions
CREATE TABLE IF NOT EXISTS conversation_sessions (
  id VARCHAR(255) PRIMARY KEY,
  context_type VARCHAR(50) NOT NULL,
  context_data JSONB DEFAULT '{}'::jsonb,
  status VARCHAR(20) DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ended_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_conversation_sessions_context_type ON conversation_sessions(context_type);
CREATE INDEX IF NOT EXISTS idx_conversation_sessions_status ON conversation_sessions(status);

COMMENT ON TABLE conversation_sessions IS 'Session management for different conversation contexts (chat, teaching, etc.)';
COMMENT ON COLUMN conversation_sessions.context_type IS 'Type: chat, teaching, task_planning, reflection';

-- =============================================================================
-- CALENDAR SYSTEM
-- =============================================================================

-- User Events (Calendar Agent - Objective Temporal Data)
CREATE TABLE IF NOT EXISTS user_events (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,

  -- Temporal information (explicit, deterministic)
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP,
  all_day BOOLEAN DEFAULT FALSE,
  timezone VARCHAR(100) DEFAULT 'UTC',

  -- Location information (structured)
  location JSONB DEFAULT '{}'::jsonb,

  -- Participants (structured array)
  participants JSONB DEFAULT '[]'::jsonb,

  -- Event classification
  event_type VARCHAR(50) NOT NULL,
  status VARCHAR(20) DEFAULT 'scheduled',

  -- Recurrence
  recurrence_rule TEXT,
  recurrence_exceptions JSONB DEFAULT '[]'::jsonb,
  parent_event_id INTEGER REFERENCES user_events(id) ON DELETE CASCADE,

  -- Reminders
  reminder_times JSONB DEFAULT '[]'::jsonb,
  reminders_sent JSONB DEFAULT '[]'::jsonb,

  -- External integration
  external_calendar_id VARCHAR(255),
  external_event_id VARCHAR(255),

  -- Metadata
  metadata JSONB DEFAULT '{}'::jsonb,

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_user_events_start_time ON user_events(start_time);
CREATE INDEX IF NOT EXISTS idx_user_events_end_time ON user_events(end_time);
CREATE INDEX IF NOT EXISTS idx_user_events_event_type ON user_events(event_type);
CREATE INDEX IF NOT EXISTS idx_user_events_status ON user_events(status);
CREATE INDEX IF NOT EXISTS idx_user_events_external_calendar ON user_events(external_calendar_id);

COMMENT ON TABLE user_events IS 'Calendar Agent - Objective, deterministic temporal data (events, appointments, deadlines)';
COMMENT ON COLUMN user_events.start_time IS 'Explicit start timestamp (never vague)';
COMMENT ON COLUMN user_events.end_time IS 'Explicit end timestamp (null for deadlines/todos)';
COMMENT ON COLUMN user_events.location IS 'Structured location: {address, place_name, coordinates: {lat, lng}, url, notes}';
COMMENT ON COLUMN user_events.participants IS 'Array of participant objects: [{name, email, role, status}]';
COMMENT ON COLUMN user_events.event_type IS 'Type: meeting, appointment, deadline, birthday, anniversary, reminder, travel, meal, exercise, personal, work, social';
COMMENT ON COLUMN user_events.status IS 'Status: scheduled, completed, cancelled, rescheduled, tentative';
COMMENT ON COLUMN user_events.recurrence_rule IS 'Natural language recurrence pattern (e.g., "every Monday and Wednesday", "first Tuesday of each month", "daily at 9am", "every other Friday")';

\echo 'Creating Motor Agent tables...'
-- =============================================================================
-- MOTOR AGENT - ACTION QUEUE & HABIT FORMATION
-- =============================================================================

-- Action Queue (Motor Cortex - Action Sequencing)
CREATE TABLE IF NOT EXISTS action_queue (
  id SERIAL PRIMARY KEY,
  action_type VARCHAR(100) NOT NULL,
  payload JSONB NOT NULL,
  priority INTEGER DEFAULT 0,
  dependencies INTEGER[] DEFAULT '{}',
  status VARCHAR(50) DEFAULT 'pending',
  scheduled_at TIMESTAMP,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  result JSONB,
  retry_count INTEGER DEFAULT 0,
  max_retries INTEGER DEFAULT 3,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_action_queue_status ON action_queue(status);
CREATE INDEX IF NOT EXISTS idx_action_queue_priority ON action_queue(priority DESC);
CREATE INDEX IF NOT EXISTS idx_action_queue_scheduled_at ON action_queue(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_action_queue_action_type ON action_queue(action_type);

COMMENT ON TABLE action_queue IS 'Motor Agent - Priority queue with dependencies for action sequencing (motor cortex analogy)';
COMMENT ON COLUMN action_queue.action_type IS 'Type: create_event, update_event, delete_event, send_reminder, create_task, etc.';
COMMENT ON COLUMN action_queue.payload IS 'Action-specific data (event details, task info, etc.)';
COMMENT ON COLUMN action_queue.dependencies IS 'Array of action IDs that must complete before this action';
COMMENT ON COLUMN action_queue.status IS 'Status: pending, in_progress, completed, failed, cancelled';

-- Created Content (Tempo Agent - Content Generation Archive)
CREATE TABLE IF NOT EXISTS created_content (
  id SERIAL PRIMARY KEY,
  action_id INTEGER REFERENCES action_queue(id),
  content_type VARCHAR(50) NOT NULL,
  purpose TEXT NOT NULL,
  content TEXT NOT NULL,
  tone VARCHAR(50),
  length VARCHAR(20),
  word_count INTEGER,
  processing_time_ms INTEGER,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_created_content_type ON created_content(content_type);
CREATE INDEX IF NOT EXISTS idx_created_content_created_at ON created_content(created_at DESC);

COMMENT ON TABLE created_content IS 'Tempo Agent - Archive of all generated content for debugging, error handling, and retrieval';
COMMENT ON COLUMN created_content.content_type IS 'Type: email, report, article, review, summary, letter, social_post, creative';
COMMENT ON COLUMN created_content.purpose IS 'User-provided purpose/description of what they wanted';

-- Habit Patterns (Basal Ganglia - Pattern Learning)
CREATE TABLE IF NOT EXISTS habit_patterns (
  id SERIAL PRIMARY KEY,
  action_type VARCHAR(100) NOT NULL UNIQUE,
  pattern_data JSONB NOT NULL,
  frequency_score FLOAT DEFAULT 0,
  consistency_score FLOAT DEFAULT 0,
  success_rate FLOAT DEFAULT 0,
  total_occurrences INTEGER DEFAULT 0,
  last_executed TIMESTAMP,
  next_suggested TIMESTAMP,
  confidence FLOAT DEFAULT 0,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_habit_patterns_action_type ON habit_patterns(action_type);
CREATE INDEX IF NOT EXISTS idx_habit_patterns_confidence ON habit_patterns(confidence DESC);
CREATE INDEX IF NOT EXISTS idx_habit_patterns_next_suggested ON habit_patterns(next_suggested);

COMMENT ON TABLE habit_patterns IS 'Motor Agent - Habit formation and pattern detection (basal ganglia analogy)';
COMMENT ON COLUMN habit_patterns.action_type IS 'Type of action that forms a pattern';
COMMENT ON COLUMN habit_patterns.pattern_data IS 'Pattern details: time of day, day of week, triggers, context';
COMMENT ON COLUMN habit_patterns.frequency_score IS 'How often this pattern occurs (0.0-1.0)';
COMMENT ON COLUMN habit_patterns.consistency_score IS 'How consistent the pattern is (0.0-1.0)';
COMMENT ON COLUMN habit_patterns.success_rate IS 'How often the pattern leads to successful actions (0.0-1.0)';

-- Executive Feedback (Learning from Outcomes)
CREATE TABLE IF NOT EXISTS executive_feedback (
  id SERIAL PRIMARY KEY,
  action_id INTEGER REFERENCES action_queue(id) ON DELETE CASCADE,
  outcome VARCHAR(50) NOT NULL,
  feedback_type VARCHAR(50),
  feedback_data JSONB,
  learning JSONB,
  applied_to_pattern BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_executive_feedback_action_id ON executive_feedback(action_id);
CREATE INDEX IF NOT EXISTS idx_executive_feedback_outcome ON executive_feedback(outcome);
CREATE INDEX IF NOT EXISTS idx_executive_feedback_created_at ON executive_feedback(created_at DESC);

COMMENT ON TABLE executive_feedback IS 'Motor Agent - Learning from action outcomes to improve future behavior';
COMMENT ON COLUMN executive_feedback.outcome IS 'Outcome: success, failure, partial_success, user_override, cancelled';
COMMENT ON COLUMN executive_feedback.feedback_type IS 'Type: user_correction, system_error, timing_issue, conflict_detected, etc.';
COMMENT ON COLUMN executive_feedback.learning IS 'What was learned: {insight, adjustment, pattern_update}';

\echo 'Creating triggers and functions...'
-- =============================================================================
-- TRIGGERS & FUNCTIONS
-- =============================================================================

-- Updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at triggers
CREATE TRIGGER trigger_user_profile_updated_at
  BEFORE UPDATE ON user_profile
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_user_memories_updated_at
  BEFORE UPDATE ON user_memories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_relationship_state_updated_at
  BEFORE UPDATE ON relationship_state
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_user_events_updated_at
  BEFORE UPDATE ON user_events
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_action_queue_updated_at
  BEFORE UPDATE ON action_queue
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_habit_patterns_updated_at
  BEFORE UPDATE ON habit_patterns
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_conversation_sessions_updated_at
  BEFORE UPDATE ON conversation_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Interaction tracking trigger function
CREATE OR REPLACE FUNCTION update_interaction_tracking()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE relationship_state
  SET
    interaction_count = interaction_count + 1,
    last_interaction_at = CURRENT_TIMESTAMP,
    days_since_last_interaction = 0;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_interaction_tracking
  AFTER INSERT ON conversation_history
  FOR EACH ROW
  WHEN (NEW.role = 'user')
  EXECUTE FUNCTION update_interaction_tracking();

-- =============================================================================
-- VECTOR INDEXES (created after data is loaded)
-- =============================================================================

-- Note: Vector indexes will be created automatically by the application
-- when sufficient data exists (100+ vectors recommended for IVFFlat)
-- Uncomment these if you're loading data via this script:

-- CREATE INDEX IF NOT EXISTS knowledge_embeddings_vector_idx
--   ON knowledge_embeddings
--   USING ivfflat (embedding vector_cosine_ops)
--   WITH (lists = 100);

-- CREATE INDEX IF NOT EXISTS idx_user_memories_embedding
--   ON user_memories
--   USING ivfflat (embedding vector_cosine_ops)
--   WITH (lists = 100);

-- CREATE INDEX IF NOT EXISTS graph_entities_vector_idx
--   ON graph_entities
--   USING ivfflat (embedding vector_cosine_ops)
--   WITH (lists = 100);

\echo 'Initializing default data...'
-- =============================================================================
-- INITIAL DATA
-- =============================================================================

-- Initialize single user profile
INSERT INTO user_profile (timezone, preferences)
VALUES ('UTC', '{}'::jsonb)
ON CONFLICT DO NOTHING;

-- Initialize single relationship state
INSERT INTO relationship_state (relationship_strength, recent_trend)
VALUES (0.0, 'new')
ON CONFLICT DO NOTHING;

-- Initialize Niimi identity (not yet generated, will be created when trust is established)
INSERT INTO niimi_identity (revealed, generated_at)
VALUES (FALSE, NULL)
ON CONFLICT DO NOTHING;

-- Initialize Niimi emotional state (starts curious and cautious)
INSERT INTO niimi_emotional_state (
  understanding_of_user,
  trust_in_user,
  reciprocity_perceived,
  vulnerability_willingness,
  current_mood,
  emotional_keywords
)
VALUES (
  0.0,
  0.0,
  0.0,
  0.0,
  'curious',
  ARRAY['new_relationship', 'learning', 'cautious']::TEXT[]
)
ON CONFLICT DO NOTHING;

-- =============================================================================
-- SYSTEM KNOWLEDGE: Niimi Architecture Documentation
-- =============================================================================
-- Load foundational knowledge about Niimi's architecture
-- This data is marked as is_system=TRUE and protected from modification
\echo 'Loading system knowledge...'
\i database/system-knowledge.sql

\echo ''
\echo '======================================'
\echo 'Installation Complete!'
\echo '======================================'
\echo ''
\echo 'Database tables created successfully.'
\echo 'You can now run Niimi with: ./niimi'
\echo ''
