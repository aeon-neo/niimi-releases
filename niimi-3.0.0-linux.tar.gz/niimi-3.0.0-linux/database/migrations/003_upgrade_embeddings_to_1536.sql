-- Migration 003: Upgrade Embeddings from 768 to 1536 Dimensions
--
-- This migration upgrades all vector columns from 768-dimensional (HuggingFace all-mpnet-base-v2)
-- to 1536-dimensional (OpenAI text-embedding-3-small).
--
-- IMPORTANT: This migration will NULL out all existing embeddings.
-- After running this migration, you must re-vectorize all documents:
--   npm run vectorize <collection-name>
--
-- The OpenAI embeddings offer:
--   - Much lighter memory footprint (no local model loading)
--   - Higher quality embeddings
--   - Faster inference (API call vs local GPU/CPU)
--
-- Run with: psql -h localhost -U postgres -d niimi_db < database/migrations/003_upgrade_embeddings_to_1536.sql

-- =============================================================================
-- UPGRADE KNOWLEDGE EMBEDDINGS TABLE
-- =============================================================================

-- Step 1: NULL out existing embeddings (they're 768-dim, incompatible with 1536)
UPDATE knowledge_embeddings SET embedding = NULL WHERE embedding IS NOT NULL;

-- Step 2: Change column type to 1536 dimensions
ALTER TABLE knowledge_embeddings
  ALTER COLUMN embedding TYPE vector(1536);

-- Step 3: Update comment
COMMENT ON COLUMN knowledge_embeddings.embedding IS 'OpenAI text-embedding-3-small (1536 dimensions)';

-- =============================================================================
-- UPGRADE USER MEMORIES TABLE
-- =============================================================================

-- Step 1: NULL out existing embeddings
UPDATE user_memories SET embedding = NULL WHERE embedding IS NOT NULL;

-- Step 2: Change column type to 1536 dimensions
ALTER TABLE user_memories
  ALTER COLUMN embedding TYPE vector(1536);

-- Step 3: Update comment
COMMENT ON COLUMN user_memories.embedding IS 'OpenAI text-embedding-3-small (1536 dimensions)';

-- =============================================================================
-- UPGRADE LESSON PLAN EMBEDDINGS TABLE (if exists)
-- =============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'lesson_plan_embeddings') THEN
    -- NULL out existing embeddings
    UPDATE lesson_plan_embeddings SET embedding = NULL WHERE embedding IS NOT NULL;
    -- Change column type
    ALTER TABLE lesson_plan_embeddings
      ALTER COLUMN embedding TYPE vector(1536);
    COMMENT ON COLUMN lesson_plan_embeddings.embedding IS 'OpenAI text-embedding-3-small (1536 dimensions)';
    RAISE NOTICE 'Upgraded lesson_plan_embeddings to 1536 dimensions';
  END IF;
END $$;

-- =============================================================================
-- UPGRADE TASK RULES TABLE (if exists)
-- =============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'task_rules') THEN
    IF EXISTS (SELECT 1 FROM information_schema.columns
               WHERE table_name = 'task_rules' AND column_name = 'embedding') THEN
      -- NULL out existing embeddings
      UPDATE task_rules SET embedding = NULL WHERE embedding IS NOT NULL;
      -- Change column type
      ALTER TABLE task_rules
        ALTER COLUMN embedding TYPE vector(1536);
      COMMENT ON COLUMN task_rules.embedding IS 'OpenAI text-embedding-3-small (1536 dimensions)';
      RAISE NOTICE 'Upgraded task_rules to 1536 dimensions';
    END IF;
  END IF;
END $$;

-- =============================================================================
-- UPGRADE GRAPH ENTITIES TABLE (if exists)
-- =============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'graph_entities') THEN
    IF EXISTS (SELECT 1 FROM information_schema.columns
               WHERE table_name = 'graph_entities' AND column_name = 'embedding') THEN
      -- NULL out existing embeddings
      UPDATE graph_entities SET embedding = NULL WHERE embedding IS NOT NULL;
      -- Change column type
      ALTER TABLE graph_entities
        ALTER COLUMN embedding TYPE vector(1536);
      COMMENT ON COLUMN graph_entities.embedding IS 'OpenAI text-embedding-3-small (1536 dimensions)';
      RAISE NOTICE 'Upgraded graph_entities to 1536 dimensions';
    END IF;
  END IF;
END $$;

-- =============================================================================
-- RECREATE VECTOR INDEXES (IVFFlat indexes need recreation after dimension change)
-- =============================================================================

-- Drop and recreate knowledge_embeddings index
DROP INDEX IF EXISTS idx_knowledge_embeddings_vector;
CREATE INDEX idx_knowledge_embeddings_vector ON knowledge_embeddings
  USING ivfflat (embedding vector_cosine_ops)
  WITH (lists = 100);

-- Drop and recreate user_memories index
DROP INDEX IF EXISTS idx_user_memories_embedding;
CREATE INDEX idx_user_memories_embedding ON user_memories
  USING ivfflat (embedding vector_cosine_ops)
  WITH (lists = 100);

-- =============================================================================
-- VERIFICATION
-- =============================================================================

DO $$
DECLARE
  ke_dim INTEGER;
  um_dim INTEGER;
BEGIN
  -- Check knowledge_embeddings dimension
  SELECT atttypmod - 4 INTO ke_dim
  FROM pg_attribute
  WHERE attrelid = 'knowledge_embeddings'::regclass
    AND attname = 'embedding';

  IF ke_dim = 1536 THEN
    RAISE NOTICE 'SUCCESS: knowledge_embeddings.embedding is now 1536 dimensions';
  ELSE
    RAISE WARNING 'FAILED: knowledge_embeddings.embedding is % dimensions (expected 1536)', ke_dim;
  END IF;

  -- Check user_memories dimension
  SELECT atttypmod - 4 INTO um_dim
  FROM pg_attribute
  WHERE attrelid = 'user_memories'::regclass
    AND attname = 'embedding';

  IF um_dim = 1536 THEN
    RAISE NOTICE 'SUCCESS: user_memories.embedding is now 1536 dimensions';
  ELSE
    RAISE WARNING 'FAILED: user_memories.embedding is % dimensions (expected 1536)', um_dim;
  END IF;
END $$;

-- =============================================================================
-- POST-MIGRATION INSTRUCTIONS
-- =============================================================================

DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '=============================================================================';
  RAISE NOTICE 'MIGRATION COMPLETE: Embeddings upgraded to 1536 dimensions';
  RAISE NOTICE '=============================================================================';
  RAISE NOTICE '';
  RAISE NOTICE 'All existing embeddings have been set to NULL.';
  RAISE NOTICE 'You must now re-vectorize your documents:';
  RAISE NOTICE '';
  RAISE NOTICE '  1. Re-vectorize knowledge base:';
  RAISE NOTICE '     npm run vectorize <collection-name>';
  RAISE NOTICE '';
  RAISE NOTICE '  2. Memories will be re-embedded automatically on next use';
  RAISE NOTICE '';
  RAISE NOTICE 'The new OpenAI embeddings offer:';
  RAISE NOTICE '  - 600MB+ smaller memory footprint';
  RAISE NOTICE '  - Higher quality semantic understanding';
  RAISE NOTICE '  - Faster inference via API';
  RAISE NOTICE '=============================================================================';
END $$;
