-- Migration: Add Knowledge Graph Entities Table
-- Date: 2025-11-19
-- Description: Add graph_entities table for LightRAG-style entity extraction

-- Enable vector extension (should already exist, but ensure it's available)
CREATE EXTENSION IF NOT EXISTS vector;

-- Create graph_entities table
CREATE TABLE IF NOT EXISTS graph_entities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_id VARCHAR(255) UNIQUE NOT NULL,  -- MD5 hash of normalized entity name for deduplication
  entity_name TEXT NOT NULL,
  entity_type VARCHAR(100),                -- Person, Organization, Concept, Location, Policy, etc.
  description TEXT,
  embedding vector(768) NOT NULL,          -- Match all-mpnet-base-v2 dimensions
  source_chunks VARCHAR(255)[],            -- Array of chunk IDs (knowledge_embeddings.id) mentioning this entity
  source_documents VARCHAR(255)[],         -- Array of document IDs for traceability
  mention_count INTEGER DEFAULT 1,         -- Number of times entity mentioned across chunks
  importance_score FLOAT DEFAULT 1.0,      -- Calculated importance (mention frequency + centrality)
  metadata JSONB,                          -- Flexible storage for additional attributes
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_graph_entities_name ON graph_entities(entity_name);
CREATE INDEX IF NOT EXISTS idx_graph_entities_type ON graph_entities(entity_type);
CREATE INDEX IF NOT EXISTS idx_graph_entities_entity_id ON graph_entities(entity_id);
CREATE INDEX IF NOT EXISTS idx_graph_entities_importance ON graph_entities(importance_score DESC);
CREATE INDEX IF NOT EXISTS idx_graph_entities_metadata ON graph_entities USING GIN (metadata);

-- Add table comments
COMMENT ON TABLE graph_entities IS 'Extracted entities from knowledge base for LightRAG-style graph retrieval';
COMMENT ON COLUMN graph_entities.entity_id IS 'MD5 hash of normalized entity name for fuzzy deduplication';
COMMENT ON COLUMN graph_entities.source_chunks IS 'Array of knowledge_embeddings.id where this entity appears';
COMMENT ON COLUMN graph_entities.mention_count IS 'Frequency of mentions - higher = more important';
COMMENT ON COLUMN graph_entities.importance_score IS 'Weighted importance: mention count + relationship centrality';

-- Note: Vector index will be created after sufficient data is loaded
-- Uncomment below when you have 100+ entities:
-- CREATE INDEX IF NOT EXISTS graph_entities_vector_idx
--   ON graph_entities
--   USING ivfflat (embedding vector_cosine_ops)
--   WITH (lists = 100);
