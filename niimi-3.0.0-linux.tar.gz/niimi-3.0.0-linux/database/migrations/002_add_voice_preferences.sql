-- Migration: Add Voice Preferences to User Profile
-- Description: Adds voice synthesis preferences (Hume TTS) to user_profile table
-- Date: 2025-01-25
-- Version: 3.0.1

-- Add voice preference columns to user_profile table
ALTER TABLE user_profile
  ADD COLUMN IF NOT EXISTS voice_enabled BOOLEAN DEFAULT true,
  ADD COLUMN IF NOT EXISTS voice_autoplay BOOLEAN DEFAULT true,
  ADD COLUMN IF NOT EXISTS preferred_voice VARCHAR(100) DEFAULT 'Ava Song';

-- Add column comments
COMMENT ON COLUMN user_profile.voice_enabled IS 'Enable/disable Niimi voice synthesis (Hume TTS)';
COMMENT ON COLUMN user_profile.voice_autoplay IS 'Auto-play voice responses (true) or click-to-play (false)';
COMMENT ON COLUMN user_profile.preferred_voice IS 'Hume TTS voice name (e.g. "Ava Song", "Marcus Reed")';

-- Update existing row if it exists (single-user system)
UPDATE user_profile
  SET voice_enabled = true,
      voice_autoplay = true,
      preferred_voice = 'Ava Song'
  WHERE voice_enabled IS NULL;
